﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sipgate_Aufgabe
{
    class Program
    {
        static void Main(string[] args)
        {

            decimal i = 1;
            
                


            while (i != 101)
            {
                if (i % 3 == 0)
                {

                    Console.WriteLine("Foo");
                }
                else if (i % 5 == 0)
                {
                    Console.WriteLine("Bar");
                }
                else if (i % 7 == 0)
                {
                    Console.WriteLine("Buzz");
                }
                else if (i == 3)
                {
                    Console.WriteLine("Foo");
                }
                else if (i == 5)
                {
                    Console.WriteLine("Bar");
                }
                else if (i == 7)
                {
                    Console.WriteLine("Qix");
                }
                else
                {
                    Console.WriteLine(i);
                }
  
                i++;
                 
            }
            Console.ReadKey();
        }
    }
}
