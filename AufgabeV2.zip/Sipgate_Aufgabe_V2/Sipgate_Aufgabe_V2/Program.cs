﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sipgate_Aufgabe_V2
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 1;

            while (i <= 100)
            {
                if (i % 3 == 0)
                {
                    Console.WriteLine("Foo");
                }
                else if (i % 5 == 0)
                {
                    Console.WriteLine("Bar");
                }
                else if (i % 7 == 0)
                {
                    Console.WriteLine("Buzz");
                }
                else if (i.ContainsDigit(3) || i.ContainsDigit(5) || i.ContainsDigit(7))
                {
                    Console.Write(i);
                    foreach (char c in i.ToString())
                    {
                        if (c == '3') Console.Write("Foo");
                        if (c == '5') Console.Write("Bar");
                        if (c == '7') Console.Write("Qix");
                    }
                    Console.Write(Environment.NewLine);
                }
                else
                {
                    Console.WriteLine(i);
                }

                i++;
            }

            Console.ReadKey();
        }
    }

    public static class IntegerExtensions
    {

        public static bool ContainsDigit(this int number, int digit)
        {

            if (digit < 0 || digit > 10)
            {
                throw new InvalidOperationException("Parameter digit must be a positive integer less than 10.");
            }

            return number.ToString().Contains(digit.ToString());
        }
    }
}
    

